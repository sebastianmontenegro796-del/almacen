'use strict';
/* =========================================================
   Facturas — pegas el texto de la factura (Google Lens → Copiar texto),
   la app la ordena, tú la revisas y se guarda. Luego, por semanas:
   por tipo, proveedor, día, caducidad, comparación con el almacén,
   subidas/bajadas de precio y cada cuánto se pide cada cosa.
   No cambia el stock del almacén: solo lo lee para comparar.
   Usa api(), toast(), esc(), fmt(), cantUd(), unidadNorm(), $, showView() de app.js.
   ========================================================= */
(function () {
  const BORRADOR = 'seba_factura_borrador';
  const guardarBorrador = v => { try { v ? localStorage.setItem(BORRADOR, v) : localStorage.removeItem(BORRADOR); } catch {} };
  const leerBorrador = () => { try { return localStorage.getItem(BORRADOR) || ''; } catch { return ''; } };
  const norm = s => String(s ?? '').normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase();
  const clave = d => norm(d).replace(/[^a-z0-9ñ]+/g, ' ').trim();
  const euro = n => n == null || n === '' || isNaN(n) ? '' : Number(n).toLocaleString('es-ES', {style: 'currency', currency: 'EUR'});
  const UNIDADES_F = ['Caja', 'Unidad', 'Palé', 'Medio palé', 'Fila'];

  /* ---------- Fechas ---------- */
  const iso = d => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
  const deIso = s => { const [y, m, d] = String(s).slice(0, 10).split('-').map(Number); return new Date(y, m - 1, d); };
  const lunes = d => { const x = new Date(d.getFullYear(), d.getMonth(), d.getDate()); x.setDate(x.getDate() - ((x.getDay() + 6) % 7)); return x; };
  const masDias = (d, n) => { const x = new Date(d); x.setDate(x.getDate() + n); return x; };
  const dias = (a, b) => Math.round((deIso(b) - deIso(a)) / 86400000);
  const MESES = ['ene', 'feb', 'mar', 'abr', 'may', 'jun', 'jul', 'ago', 'sep', 'oct', 'nov', 'dic'];
  const DIAS = ['domingo', 'lunes', 'martes', 'miércoles', 'jueves', 'viernes', 'sábado'];
  const corta = s => { const d = deIso(s); return `${d.getDate()} ${MESES[d.getMonth()]}`; };
  const larga = s => { const d = deIso(s); return `${DIAS[d.getDay()]} ${d.getDate()} ${MESES[d.getMonth()]}`; };

  /* ---------- Tipos de producto ---------- */
  const TIPOS = ['Cerveza', 'Refrescos', 'Agua', 'Zumos', 'Energéticas e isotónicas', 'Vino y licores', 'Lácteos y batidos',
    'Chocolate', 'Chuches', 'Snacks', 'Galletas y bollería', 'Otros'];
  const PISTAS = [
    ['Energéticas e isotónicas', 'red bull|monster|burn|energy|rockstar|isostar|powerade|gatorade|isotonic'],
    ['Cerveza', 'cerveza|cerv\\b|mahou|estrella|cruzcampo|heineken|amstel|san miguel|alhambra|damm|voll|coronita|corona|budweiser|desperados|keler|ambar|radler|shandy|lager|1906|alcazar|victoria'],
    ['Agua', '\\bagua\\b|lanjaron|solan|bezoya|aquabona|viladrau|cabreiroa|font vella|fontvella|veri\\b'],
    ['Refrescos', 'coca|cola\\b|fanta|sprite|pepsi|7 ?up|seven|schweppes|\\bkas\\b|trina|nestea|aquarius|tonica|gaseosa|refresco|fuze|lipton|bitter|casera|mirinda|ice tea'],
    ['Zumos', 'zumo|nectar|don simon|granini|juver|minute maid|bifrutas'],
    ['Vino y licores', 'vino|rioja|ribera|\\bcava\\b|\\bron\\b|whisky|ginebra|\\bgin\\b|vodka|licor|sangria|tinto|vermut|brandy|anis|champan|sidra|tequila|tinto de verano'],
    ['Lácteos y batidos', 'leche|batido|cacaolat|yogur|puleva|actimel|kefir|nata'],
    ['Galletas y bollería', 'galleta|oreo|principe|bollo|donut|bolleria|magdalena|croissant|napolitana|bimbo|phoskitos|tigreton|pantera rosa|bizcocho'],
    ['Chocolate', 'chocolate|choco|kinder|snickers|twix|\\bmars\\b|kit ?kat|milka|huesito|bounty|ferrero|toblerone|lacasitos|conguitos|maltesers|m&m|nestle'],
    ['Snacks', 'patata|papas|snack|lays|ruffles|doritos|cheetos|pringles|matutano|risi|frutos secos|pipas|cacahuete|almendra|kiko|palomitas|gusanito|grefusa|facundo|churruca|nachos'],
    ['Chuches', 'chuche|gominola|golosina|regaliz|fini|haribo|vidal|damel|\\bbang\\b|toffee|caramelo|chicle|pictolin|pixolin|piruleta|chupa|palote|torcida|mentol|jelly|tarro|party mix|bom ?bom|trident|smint|halls|sugus|pica pica|nube|ositos|gelatina|capi pari|lacasa'],
  ].map(([t, re]) => [t, new RegExp(re)]);
  const adivinarTipo = d => { const n = norm(d); const h = PISTAS.find(([, re]) => re.test(n)); return h ? h[0] : 'Otros'; };

  /* ---------- Parecido con los productos del almacén (mismo criterio que Buscar lista) ---------- */
  const fichas = t => norm(t).split(/[^a-z0-9ñ]+/).filter(x => x.length >= 2 || /\d/.test(x));
  const casa = (a, b) => a === b || (a.length >= 3 && b.length >= 3 && (a.startsWith(b) || b.startsWith(a)));
  function parecido(nombre, p) {
    const q = fichas(nombre), t = fichas(p.nombre + ' ' + (p.referencia || ''));
    if (!q.length || !t.length) return 0;
    const tn = fichas(p.nombre);
    const deP = tn.filter(y => q.some(x => casa(x, y))).length / (tn.length || 1);   // cuánto del nombre del almacén sale en la factura
    const deQ = q.filter(x => t.some(y => casa(x, y))).length / q.length;
    return deP * 0.75 + deQ * 0.25;
  }

  /* ---------- Leer el texto de la factura ---------- */
  const numES = t => {
    let s = String(t).replace(/[€\s]/g, '');
    if (s.includes(',')) s = s.replace(/\./g, '').replace(',', '.');
    const v = Number(s);
    return isNaN(v) ? null : v;
  };
  const MES_N = {enero: 1, febrero: 2, marzo: 3, abril: 4, mayo: 5, junio: 6, julio: 7, agosto: 8, septiembre: 9, setiembre: 9, octubre: 10, noviembre: 11, diciembre: 12};
  function fechaDe(txt, mesAnioVale) {
    let m = txt.match(/\b(\d{1,2})[\/\-.](\d{1,2})[\/\-.](\d{2,4})\b/);
    if (m) {
      let [, d, mes, y] = m.map(Number); if (y < 100) y += 2000;
      if (mes >= 1 && mes <= 12 && d >= 1 && d <= 31 && y > 2000 && y < 2100) return {iso: iso(new Date(y, mes - 1, d)), txt: m[0]};
    }
    m = norm(txt).match(/\b(\d{1,2}) de (\w+) de (\d{4})\b/);
    if (m && MES_N[m[2]]) return {iso: iso(new Date(+m[3], MES_N[m[2]] - 1, +m[1])), txt: m[0]};
    if (mesAnioVale) {
      m = txt.match(/\b(\d{1,2})[\/\-.](\d{4}|\d{2})\b/);
      if (m) {
        let mes = +m[1], y = +m[2]; if (y < 100) y += 2000;
        if (mes >= 1 && mes <= 12 && y > 2000 && y < 2100) return {iso: iso(new Date(y, mes, 0)), txt: m[0]};   // último día del mes
      }
    }
    return null;
  }
  const NO_PRODUCTO = /\b(total|subtotal|sub-total|base imp|bases? imponible|i\.?v\.?a|recargo|r\.e\.|forma de pago|vencimiento|cliente|n\.?i\.?f|c\.?i\.?f|tel[eé]f|tlf|fax|e-?mail|www\.|http|direcci[oó]n|domicilio|c\/|calle|avda|avenida|pol[ií]gono|c\.?p\.?\s*\d|factura|fecha|albar[aá]n|p[aá]gina|banco|iban|cuenta|portes|importe neto|observaciones|registro mercantil|tomo|folio|inscrita|gracias|firma|transportista|pedido n)\b/i;
  const ES_CABECERA = /(descripci[oó]n|art[ií]culo|concepto|producto).*(cant|uds|unid|precio|importe)|(cant|uds|unid).*(descripci[oó]n|art[ií]culo|concepto)/i;
  const ES_NUM = /^-?\d{1,3}(?:\.\d{3})*(?:,\d+)?$|^-?\d+(?:[.,]\d+)?$/;

  function leerFila(linea) {
    let s = ' ' + linea.replace(/\s+/g, ' ') + ' ';
    let caducidad = '';
    const mc = s.match(/(?:cad\w*|f\.?\s?cad|cp|fcp|exp|cons\.? pref\w*|lote\/cad)\.?\s*:?\s*(\d{1,2}[\/\-.]\d{1,2}[\/\-.]\d{2,4}|\d{1,2}[\/\-.]\d{2,4})/i);
    if (mc) { const f = fechaDe(mc[1], true); if (f) { caducidad = f.iso; s = s.replace(mc[0], ' '); } }
    else { const f = fechaDe(s, false); if (f) { caducidad = f.iso; s = s.replace(f.txt, ' '); } }   // una fecha dentro de la fila suele ser la caducidad
    const t = s.trim().split(' ').filter(Boolean);
    while (t.length && /^\d{6,14}$/.test(t[0])) t.shift();         // código de barras / referencia al principio
    const nums = [];
    while (t.length) {
      const x = t[t.length - 1].replace(/€$/, '');
      if (x === '' || x === '€' || /^[x×]$/i.test(x)) { t.pop(); continue; }
      if (/%$/.test(x) && ES_NUM.test(x.slice(0, -1))) { t.pop(); continue; }    // descuentos / IVA
      if (/^\d{8,14}$/.test(x)) { t.pop(); continue; }                          // código de barras al final
      if (!ES_NUM.test(x)) break;
      nums.unshift(numES(x)); t.pop();
    }
    while (t.length && /^\d{4,7}$/.test(t[0]) && t.length > 1) t.shift();   // referencia interna
    let cant = null;
    if (t.length > 1 && /^\d{1,3}$/.test(t[0]) && !nums.length) cant = Number(t.shift());   // «2 AQUARIUS…»
    const desc = t.join(' ').replace(/^[-–,.:;]+|[-–,.:;]+$/g, '').trim();
    let precio = null, importe = null;
    const v = nums.filter(n => n != null);
    if (v.length >= 3) {
      importe = v[v.length - 1];
      let mejor = null;
      for (let i = 0; i < v.length - 1; i++) for (let j = i + 1; j < v.length - 1; j++) {
        const err = importe ? Math.abs(v[i] * v[j] - importe) / importe : 1;
        if (err < 0.03 && (!mejor || err < mejor.err)) mejor = {i, j, err};
      }
      if (mejor) {
        const a = v[mejor.i], b = v[mejor.j];
        const aEntero = Number.isInteger(a), bEntero = Number.isInteger(b);
        [cant, precio] = aEntero && !bEntero ? [a, b] : bEntero && !aEntero ? [b, a] : [a, b];
      } else { cant = v[0]; precio = v[1]; }
    } else if (v.length === 2) {
      cant = v[0]; importe = v[1];
      if (cant) precio = Math.round(importe / cant * 10000) / 10000;
    } else if (v.length === 1) {
      if (Number.isInteger(v[0]) && v[0] < 1000) cant = v[0]; else importe = v[0];
    }
    if (cant != null && (cant <= 0 || cant > 100000)) cant = null;
    return {descripcion: desc, cantidad: cant, precio, importe, caducidad, conNumeros: v.length > 0 || cant != null};
  }

  function leerFactura(texto, proveedores) {
    const lineas = texto.replace(/\\([-+*_#.()!\[\]])/g, '$1').split(/\r\n|\r|\n/).map(l => l.replace(/\*\*/g, '').trim()).filter(Boolean);
    const f = {proveedor: '', numero: '', fecha: '', total: null, lineas: []};
    // proveedor: uno que ya conozcamos, o la primera línea con pinta de empresa
    const conocido = proveedores.find(p => lineas.slice(0, 20).some(l => norm(l).includes(norm(p))));
    if (conocido) f.proveedor = conocido;
    else {
      const cab = lineas.slice(0, 10).filter(l => /[a-záéíóúñ]{3}/i.test(l) && l.length <= 60 && !NO_PRODUCTO.test(l) && !/\d{5}/.test(l));
      f.proveedor = (cab.find(l => /\b(s\.?\s?l\.?u?|s\.?\s?a\.?|s\.?\s?coop|distribuci|bebidas|comercial|hermanos|hnos)\b/i.test(l)) || cab[0] || '').replace(/[.,;:]+$/, '');
    }
    const lf = lineas.find(l => /fecha/i.test(l) && fechaDe(l)) || lineas.find(l => !/cad|lote|venc/i.test(l) && fechaDe(l));
    if (lf) f.fecha = fechaDe(lf).iso;
    for (const l of lineas) {
      const m = l.match(/(?:factura|fra\.?|albar[aá]n|n[º°o]\.?\s*(?:de\s*)?(?:factura|documento))\s*(?:n[º°o.]*|num\.?|número)?\s*[:#]?\s*([A-Z]{0,4}[-\/]?\d[\w\-\/]{1,20})/i);
      if (m) { f.numero = m[1]; break; }
    }
    const lt = lineas.filter(l => /total/i.test(l) && !/sub-?total|total\s*(bruto|iva|base|dto|uds|unidades|bultos|kg)/i.test(l));
    for (const l of lt) {
      const ns = (l.match(/\d{1,3}(?:\.\d{3})*,\d{2}|\d+[.,]\d{2}/g) || []).map(numES).filter(n => n != null);
      if (ns.length) f.total = ns[ns.length - 1];
    }
    const iCab = lineas.findIndex(l => ES_CABECERA.test(l));
    const iFin = (() => { const i = lineas.findIndex((l, k) => k > iCab && /^(sub)?total|base imponible|suma y sigue/i.test(norm(l))); return i < 0 ? lineas.length : i; })();
    const filas = [], soloTexto = [];
    lineas.forEach((l, k) => {
      if (k === iCab || (iCab >= 0 && k < iCab) || k >= iFin) return;
      if (l === f.proveedor || NO_PRODUCTO.test(l) || ES_CABECERA.test(l)) return;
      if (!/[a-záéíóúñ]{3}/i.test(l)) return;
      const r = leerFila(l);
      if (!r.descripcion || !/[a-záéíóúñ]{2}/i.test(r.descripcion)) return;
      (r.conNumeros ? filas : soloTexto).push(r);
    });
    // Si Lens copió la tabla por columnas (sin números en las filas), al menos salen los productos
    f.lineas = filas.length >= 2 || iCab < 0 ? filas : filas.concat(soloTexto);
    f.columnas = filas.length < 2 && soloTexto.length > 0 && iCab >= 0;
    return f;
  }

  /* ---------- Pantalla ---------- */
  const vista = document.createElement('section');
  vista.id = 'view-facturas'; vista.className = 'view';
  vista.innerHTML = `
   <div class="cr" id="fcSemana">
    <h2 class="cr-tit">📑 Facturas</h2>
    <div class="fc-sem">
      <button type="button" class="btn" id="fcAnt" aria-label="Semana anterior">‹</button>
      <div class="fc-sem-t"><b id="fcSemTit"></b><small id="fcSemSub" class="muted"></small></div>
      <button type="button" class="btn" id="fcSig" aria-label="Semana siguiente">›</button>
    </div>
    <div class="cr-fila">
      <button type="button" class="btn primary cr-big" id="fcPegarLeer">📋 Pegar y leer</button>
      <button type="button" class="btn cr-big" id="fcNueva">＋ Otras formas</button>
    </div>
    <p class="muted fc-nota">Rápido: en Google Lens selecciona el texto → <b>Compartir</b> → <b>Almacén MT</b>. O cópialo y pulsa «Pegar y leer».</p>
    <div class="fc-cifras" id="fcCifras"></div>
    <div class="bl-filtros fc-filtros" id="fcFiltros">
      <button type="button" data-f="tipo" class="on">Por tipo</button>
      <button type="button" data-f="prov">Proveedor</button>
      <button type="button" data-f="dia">Por día</button>
      <button type="button" data-f="cad">Caducidad</button>
      <button type="button" data-f="alm">Almacén</button>
      <button type="button" data-f="precio">Precios</button>
      <button type="button" data-f="frec">Cada cuánto</button>
      <button type="button" data-f="lista">Facturas</button>
    </div>
    <div id="fcContenido" class="fc-contenido"></div>
   </div>

   <div class="cr" id="fcPegar" hidden>
    <h2 class="cr-tit">Meter una factura</h2>
    <ol class="fc-pasos muted">
      <li>Abre <b>Google Lens</b> (cámara de Google o Google Fotos) y apunta a la factura.</li>
      <li>Toca <b>Texto</b> → <b>Seleccionar todo</b> → <b>Copiar</b>.</li>
      <li>Vuelve aquí y pulsa <b>📋 Pegar</b>.</li>
    </ol>
    <textarea id="fcTexto" class="cr-texto" spellcheck="false" autocomplete="off"
      placeholder="Aquí aparece el texto de la factura…"></textarea>
    <div class="cr-fila">
      <button type="button" class="btn cr-big" id="fcPegarBtn">📋 Pegar</button>
      <button type="button" class="btn cr-big" id="fcVaciar">Vaciar</button>
    </div>
    <button type="button" class="btn primary cr-big cr-ancho" id="fcLeer">Leer factura →</button>
    <div class="cr-fila cr-pie">
      <button type="button" class="btn cr-big" id="fcVolver1">← Volver</button>
      <button type="button" class="btn cr-big" id="fcAMano">✍️ Escribir a mano</button>
    </div>
   </div>

   <div class="cr" id="fcRevisar" hidden>
    <h2 class="cr-tit" id="fcRevTit">Revisa la factura</h2>
    <p class="muted cr-sub" id="fcRevAyuda">Corrige lo que esté mal. La app recuerda el tipo y el producto para la próxima vez.</p>
    <div class="fc-cab">
      <label class="fc-ancho">Proveedor<input id="fcProv" list="fcProvLista" maxlength="100" autocomplete="off"></label>
      <datalist id="fcProvLista"></datalist>
      <label>Fecha factura<input id="fcFecha" type="date"></label>
      <label>Nº factura<input id="fcNum" maxlength="60" autocomplete="off"></label>
      <label>Total (€)<input id="fcTotal" inputmode="decimal" autocomplete="off"></label>
      <div class="fc-suma" id="fcSuma"></div>
    </div>
    <div id="fcLineas" class="fc-lineas"></div>
    <button type="button" class="btn cr-ancho" id="fcAddLinea">＋ Añadir producto</button>
    <p class="error" id="fcErr"></p>
    <div class="cr-fila cr-pie">
      <button type="button" class="btn cr-big" id="fcVolver2">← Atrás</button>
      <button type="button" class="btn primary cr-big" id="fcGuardar">💾 Guardar factura</button>
    </div>
   </div>`;
  document.querySelector('main').appendChild(vista);

  const paso = n => {
    ['Semana', 'Pegar', 'Revisar'].forEach(k => { $('#fc' + k).hidden = k.toLowerCase() !== n; });
    window.scrollTo({top: 0, behavior: 'smooth'});
  };
  const txt = $('#fcTexto');
  txt.value = leerBorrador();
  txt.addEventListener('input', () => guardarBorrador(txt.value));

  let semana = lunes(new Date()), datos = null, filtro = 'tipo', productos = [], memoria = new Map();
  let edit = null;   // factura en revisión: {id, proveedor, numero, fecha, total, texto, lineas:[...]}

  /* ---------- Semana: cargar y analizar ---------- */
  async function cargar() {
    $('#fcSemTit').textContent = `${corta(iso(semana))} – ${corta(iso(masDias(semana, 6)))}`;
    const hoyL = lunes(new Date());
    $('#fcSemSub').textContent = +semana === +hoyL ? 'Esta semana' : +semana === +masDias(hoyL, -7) ? 'Semana pasada' : String(semana.getFullYear());
    $('#fcContenido').innerHTML = '<p class="muted">Cargando…</p>';
    try {
      datos = await api('facturas_semana', {desde: iso(semana)});
      memoria = new Map(datos.memoria.map(m => [m.clave, m]));
      pintar();
    } catch (err) { $('#fcContenido').innerHTML = `<p class="error">${esc(err.message)}</p>`; }
  }

  // Clave para seguir un mismo producto entre facturas (precio y frecuencia)
  const claveSeg = l => {
    const pid = l.producto_id || (memoria.get(clave(l.descripcion)) || {}).producto_id;
    return pid ? 'p' + pid : 'd' + clave(l.descripcion);
  };
  const lineasSemana = () => datos.facturas.flatMap(f => f.lineas.map(l => ({...l, f})));
  const udDe = l => l.unidad || l.producto_unidad || '';
  const cantTxt = l => l.cantidad != null ? cantUd(l.cantidad, udDe(l) || 'Unidad') : '';

  function analizarPrecios() {
    const hist = datos.historial;
    const out = [];
    for (const l of lineasSemana()) {
      if (l.precio == null) continue;
      const k = claveSeg(l);
      const antes = hist.filter(h => claveSeg(h) === k && h.precio != null && (h.fecha < l.f.fecha || (h.fecha === l.f.fecha && h.id < l.id)));
      if (!antes.length) continue;
      const prev = antes[antes.length - 1];
      const a = Number(prev.precio), b = Number(l.precio);
      if (!a) continue;
      out.push({l, prev, pct: (b - a) / a * 100, a, b});
    }
    return out;
  }
  function analizarFrecuencia() {
    const grupos = new Map();
    for (const h of datos.historial) {
      const k = claveSeg(h);
      if (!grupos.has(k)) grupos.set(k, new Set());
      grupos.get(k).add(h.fecha.slice(0, 10));
    }
    const vistos = new Set(), out = [];
    for (const l of lineasSemana()) {
      const k = claveSeg(l);
      if (vistos.has(k)) continue;
      vistos.add(k);
      const fechas = [...(grupos.get(k) || [])].sort();
      const r = {l, veces: fechas.length, ultima: fechas[fechas.length - 1]};
      if (fechas.length >= 2) {
        r.cada = Math.max(1, Math.round(dias(fechas[0], r.ultima) / (fechas.length - 1)));
        r.proxima = iso(masDias(deIso(r.ultima), r.cada));
      }
      out.push(r);
    }
    return out.sort((a, b) => (a.cada || 9999) - (b.cada || 9999) || b.veces - a.veces);
  }
  function analizarAlmacen() {
    const fact = new Map();
    let sinVincular = 0;
    for (const l of lineasSemana()) {
      if (!l.producto_id) { sinVincular++; continue; }
      const k = l.producto_id;
      if (!fact.has(k)) fact.set(k, {nombre: l.producto_nombre, ud: l.producto_unidad, fact: 0, otraUd: false});
      const g = fact.get(k);
      if (l.unidad && unidadNorm(l.unidad) && unidadNorm(g.ud) && unidadNorm(l.unidad) !== unidadNorm(g.ud)) g.otraUd = l.unidad;
      g.fact += Number(l.cantidad || 0);
    }
    const ent = new Map(datos.entradas.map(e => [Number(e.producto_id), e]));
    const out = [...fact.entries()].map(([pid, g]) => {
      const e = Number((ent.get(Number(pid)) || {}).cantidad || 0);
      const dif = e - g.fact;
      return {...g, pid, ent: e, dif, estado: g.otraUd ? 'ud' : Math.abs(dif) < 0.001 ? 'ok' : dif < 0 ? 'falta' : 'sobra'};
    }).sort((a, b) => ({falta: 0, sobra: 1, ud: 2, ok: 3}[a.estado] - {falta: 0, sobra: 1, ud: 2, ok: 3}[b.estado]) || a.nombre.localeCompare(b.nombre));
    return {out, sinVincular};
  }

  const fila = (titulo, sub, extra = '', clase = '') =>
    `<div class="cr-it fc-it ${clase}"><div class="cr-t"><b>${titulo}</b><small>${sub}</small></div>${extra ? `<div class="fc-der">${extra}</div>` : ''}</div>`;
  const filaLinea = (l, conProv = true, conFecha = true) => fila(esc(l.descripcion),
    [cantTxt(l), l.precio != null ? euro(l.precio) + '/ud' : '', conProv ? esc(l.f.proveedor) : '', conFecha ? corta(l.f.fecha) : '',
      l.caducidad ? 'cad. ' + corta(l.caducidad) : ''].filter(Boolean).join(' · '),
    l.importe != null ? `<b>${euro(l.importe)}</b>` : '');
  const grupo = (titulo, sub, cuerpo) => `<details class="fc-grupo" open><summary><span>${titulo}</span><small>${sub}</small></summary>${cuerpo}</details>`;
  const sumaImp = ls => ls.reduce((s, l) => s + Number(l.importe || 0), 0);

  function pintar() {
    const ls = lineasSemana();
    const total = datos.facturas.reduce((s, f) => s + Number(f.total != null ? f.total : sumaImp(f.lineas)), 0);
    const precios = analizarPrecios();
    const subidas = precios.filter(p => p.pct > 0.5).length;
    const hoy = datos.hoy;
    const cadPronto = datos.caducidades.filter(c => dias(hoy, c.caducidad) <= 7).length;
    $('#fcCifras').innerHTML = `
      <div><b>${datos.facturas.length}</b><small>facturas</small></div>
      <div><b>${euro(total) || '0 €'}</b><small>total</small></div>
      <div class="${subidas ? 'mal' : ''}"><b>${subidas}</b><small>subidas</small></div>
      <div class="${cadPronto ? 'amb' : ''}"><b>${cadPronto}</b><small>caducan ≤7 días</small></div>`;
    document.querySelectorAll('#fcFiltros button').forEach(b => b.classList.toggle('on', b.dataset.f === filtro));
    const c = $('#fcContenido');
    if (!datos.facturas.length && filtro !== 'cad') {
      c.innerHTML = '<p class="muted fc-vacio">No hay facturas esta semana. Comparte una desde Google Lens o pulsa «📋 Pegar y leer».</p>';
      return;
    }
    let h = '';
    if (filtro === 'tipo' || filtro === 'prov') {
      const key = filtro === 'tipo' ? (l => l.tipo || 'Sin tipo') : (l => l.f.proveedor);
      const g = new Map();
      ls.forEach(l => { const k = key(l); if (!g.has(k)) g.set(k, []); g.get(k).push(l); });
      const orden = [...g.keys()].sort((a, b) => filtro === 'tipo' ? (TIPOS.indexOf(a) + 1 || 99) - (TIPOS.indexOf(b) + 1 || 99) : a.localeCompare(b));
      h = orden.map(k => {
        const gl = g.get(k);
        const nf = new Set(gl.map(l => l.f.id)).size;
        return grupo(esc(k), `${gl.length} producto${gl.length === 1 ? '' : 's'}${filtro === 'prov' ? ` · ${nf} factura${nf === 1 ? '' : 's'}` : ''} · ${euro(sumaImp(gl)) || '—'}`,
          gl.map(l => filaLinea(l, filtro === 'tipo', true)).join(''));
      }).join('');
    } else if (filtro === 'dia') {
      h = [0, 1, 2, 3, 4, 5, 6].map(i => iso(masDias(semana, i))).map(d => {
        const fs = datos.facturas.filter(f => f.fecha.slice(0, 10) === d);
        if (!fs.length) return '';
        return grupo(larga(d), `${fs.length} factura${fs.length === 1 ? '' : 's'}`,
          fs.map(f => `<div class="fc-sub">${esc(f.proveedor)}${f.numero ? ' · nº ' + esc(f.numero) : ''} <b>${euro(f.total != null ? f.total : sumaImp(f.lineas))}</b></div>` +
            f.lineas.map(l => filaLinea({...l, f}, false, false)).join('')).join(''));
      }).join('');
    } else if (filtro === 'cad') {
      const cs = datos.caducidades;
      if (!cs.length) h = '<p class="muted fc-vacio">No hay productos con caducidad apuntada. Ponla al revisar la factura.</p>';
      else {
        const tramos = [['Caducado', c => dias(hoy, c.caducidad) < 0, 'err'], ['Esta semana', c => dias(hoy, c.caducidad) <= 7, 'err'],
          ['Este mes', c => dias(hoy, c.caducidad) <= 30, 'amb'], ['Más adelante', () => true, '']];
        const usados = new Set();
        h = tramos.map(([t, fn, cl]) => {
          const g = cs.filter(x => !usados.has(x.id) && fn(x));
          g.forEach(x => usados.add(x.id));
          if (!g.length) return '';
          return grupo(t, `${g.length}`, g.map(x => {
            const d = dias(hoy, x.caducidad);
            return fila(esc(x.descripcion), [x.cantidad != null ? cantUd(x.cantidad, x.unidad || 'Unidad') : '', esc(x.proveedor), 'llegó ' + corta(x.fecha)].filter(Boolean).join(' · '),
              `<b>${corta(x.caducidad)}</b><small>${d < 0 ? `hace ${-d} d` : d === 0 ? 'hoy' : `en ${d} d`}</small>`, cl);
          }).join(''));
        }).join('');
      }
    } else if (filtro === 'alm') {
      const {out, sinVincular} = analizarAlmacen();
      h = `<p class="muted fc-nota">Lo que dicen las facturas de la semana frente a lo que se metió en el almacén (entradas y altas).</p>`;
      if (sinVincular) h += `<p class="fc-aviso">⚠️ ${sinVincular} producto${sinVincular === 1 ? '' : 's'} de las facturas sin vincular a un producto del almacén. Abre la factura en «Facturas» y elige el producto para poder comparar.</p>`;
      h += out.map(r => {
        const ic = {ok: '✅', falta: '⚠️', sobra: '🔺', ud: '❓'}[r.estado];
        const msg = r.estado === 'ok' ? 'Cuadra' : r.estado === 'falta' ? `Faltan por meter ${cantUd(-r.dif, r.ud)}` :
          r.estado === 'sobra' ? `Entró ${cantUd(r.dif, r.ud)} más de lo facturado` : `En la factura va en ${r.otraUd} y en el almacén en ${r.ud}: revísalo`;
        return fila(`${ic} ${esc(r.nombre)}`, `Facturado ${esc(cantUd(r.fact, r.ud))} · metido ${esc(cantUd(r.ent, r.ud))} — ${esc(msg)}`, '',
          {ok: 'ok', falta: 'amb', sobra: 'amb', ud: 'amb'}[r.estado]);
      }).join('') || '<p class="muted fc-vacio">Ningún producto vinculado todavía.</p>';
    } else if (filtro === 'precio') {
      const sube = precios.filter(p => p.pct > 0.5).sort((a, b) => b.pct - a.pct);
      const baja = precios.filter(p => p.pct < -0.5).sort((a, b) => a.pct - b.pct);
      const igual = precios.length - sube.length - baja.length;
      const f = (p, cl) => fila(esc(p.l.descripcion), `${euro(p.a)} → ${euro(p.b)} · antes el ${corta(p.prev.fecha)}` +
          (p.prev.proveedor !== p.l.f.proveedor ? ` (${esc(p.prev.proveedor)}, ahora ${esc(p.l.f.proveedor)})` : ` · ${esc(p.l.f.proveedor)}`),
        `<b>${p.pct > 0 ? '▲ +' : '▼ '}${fmt(Math.round(p.pct * 10) / 10)}%</b>`, cl);
      h = (sube.length ? grupo('▲ Han subido', `${sube.length}`, sube.map(p => f(p, 'err')).join('')) : '') +
        (baja.length ? grupo('▼ Han bajado', `${baja.length}`, baja.map(p => f(p, 'ok')).join('')) : '') +
        `<p class="muted fc-nota">${igual} sin cambios. Se compara con la última factura anterior del mismo producto (últimos 6 meses).</p>`;
      if (!precios.length) h = '<p class="muted fc-vacio">Aún no hay facturas anteriores con estos productos para comparar precios.</p>';
    } else if (filtro === 'frec') {
      h = analizarFrecuencia().map(r => fila(esc(r.l.descripcion),
        r.cada ? `Pedido ${r.veces} veces en 6 meses · última ${corta(r.ultima)} · próxima aprox. ${corta(r.proxima)}` : 'Primera vez en los últimos 6 meses',
        r.cada ? `<b>cada ${r.cada} d</b>` : '<small>nuevo</small>')).join('') +
        '<p class="muted fc-nota">Calculado con las fechas de factura de los últimos 6 meses.</p>';
    } else if (filtro === 'lista') {
      h = datos.facturas.map(f => fila(`${esc(f.proveedor)}${f.numero ? ' · nº ' + esc(f.numero) : ''}`,
        `${larga(f.fecha)} · ${f.lineas.length} producto${f.lineas.length === 1 ? '' : 's'}`,
        `<b>${euro(f.total != null ? f.total : sumaImp(f.lineas))}</b><span class="fc-acc"><button type="button" class="btn sm" data-editar="${f.id}">Abrir</button><button type="button" class="btn sm danger" data-borrar="${f.id}">Borrar</button></span>`)).join('');
    }
    c.innerHTML = h || '<p class="muted fc-vacio">Nada que mostrar.</p>';
  }

  /* ---------- Revisar / editar una factura ---------- */
  async function cargarProductos() {
    try { productos = (await api('productos')).slice().sort((a, b) => a.nombre.localeCompare(b.nombre)); } catch { productos = productos || []; }
  }
  function prepararLinea(l) {
    const m = memoria.get(clave(l.descripcion)) || {};
    const coma = v => v == null || v === '' ? '' : String(Number(v)).replace('.', ',');
    const x = {descripcion: l.descripcion || '', cantidad: coma(l.cantidad), unidad: l.unidad || '', precio: coma(l.precio), importe: coma(l.importe),
      caducidad: (l.caducidad || '').slice(0, 10), tipo: l.tipo || m.tipo || (l.descripcion ? adivinarTipo(l.descripcion) : ''),
      producto_id: l.producto_id || m.producto_id || null};
    if (!x.producto_id && x.descripcion) {
      // vincula solo si está claro: todas las palabras del producto del almacén salen en la factura y no hay empate
      const [m1, m2] = productos.map(p => ({p, s: parecido(x.descripcion, p)})).sort((a, b) => b.s - a.s);
      if (m1 && m1.s >= 0.85 && (!m2 || m2.s < m1.s)) x.producto_id = m1.p.id;
    }
    if (!x.unidad) { const p = productos.find(p => p.id == x.producto_id); x.unidad = p ? (unidadNorm(p.unidad) || 'Caja') : 'Caja'; }
    return x;
  }
  function opcionesProducto(l) {
    const cand = l.descripcion ? productos.map(p => ({p, s: parecido(l.descripcion, p)})).filter(x => x.s >= 0.34).sort((a, b) => b.s - a.s).slice(0, 6).map(x => x.p) : [];
    const op = p => `<option value="${p.id}"${p.id == l.producto_id ? ' selected' : ''}>${esc(p.nombre)}${p.ubicacion ? ' · ' + esc(p.ubicacion) : ''}</option>`;
    return `<option value="">— Sin vincular —</option>` +
      (cand.length ? `<optgroup label="Parecidos">${cand.map(op).join('')}</optgroup>` : '') +
      `<optgroup label="Todos">${productos.filter(p => !cand.includes(p)).map(op).join('')}</optgroup>`;
  }
  function pintarLineas() {
    $('#fcLineas').innerHTML = edit.lineas.map((l, i) => `
      <div class="fc-lin" data-i="${i}">
        <div class="fc-lin-1"><span class="fc-n">${i + 1}</span><input data-k="descripcion" value="${esc(l.descripcion)}" placeholder="Producto" maxlength="200">
          <button type="button" class="btn sm link" data-quitar="${i}" aria-label="Quitar">✕</button></div>
        <div class="fc-lin-2">
          <label>Cant.<input data-k="cantidad" value="${esc(l.cantidad)}" inputmode="decimal"></label>
          <label>Unidad<select data-k="unidad">${UNIDADES_F.concat(UNIDADES_F.includes(l.unidad) || !l.unidad ? [] : [l.unidad]).map(u => `<option${u === l.unidad ? ' selected' : ''}>${esc(u)}</option>`).join('')}</select></label>
          <label>Precio/ud<input data-k="precio" value="${esc(l.precio)}" inputmode="decimal"></label>
          <label>Importe<input data-k="importe" value="${esc(l.importe)}" inputmode="decimal"></label>
        </div>
        <div class="fc-lin-2">
          <label>Tipo<select data-k="tipo"><option value="">—</option>${TIPOS.map(t => `<option${t === l.tipo ? ' selected' : ''}>${esc(t)}</option>`).join('')}</select></label>
          <label>Caducidad<input data-k="caducidad" type="date" value="${esc(l.caducidad)}"></label>
        </div>
        <label class="fc-prod">Producto del almacén<select data-k="producto_id">${opcionesProducto(l)}</select></label>
      </div>`).join('') || '<p class="muted">No he encontrado productos. Añádelos con «＋ Añadir producto».</p>';
    pintarSuma();
  }
  function pintarSuma() {
    const s = edit.lineas.reduce((t, l) => t + (Number(String(l.importe).replace(',', '.')) || 0), 0);
    const tot = Number(String($('#fcTotal').value).replace(',', '.'));
    const sinIva = tot && s ? `<small class="muted"> · la factura dice ${euro(tot)}${Math.abs(tot - s) > 0.05 ? ' (la diferencia suele ser IVA o portes)' : ' ✅'}</small>` : '';
    $('#fcSuma').innerHTML = `${edit.lineas.length} productos · suma ${euro(s) || '0 €'}${sinIva}`;
  }
  $('#fcLineas').addEventListener('input', e => {
    const el = e.target.closest('[data-k]'); if (!el) return;
    const i = +el.closest('.fc-lin').dataset.i, k = el.dataset.k, l = edit.lineas[i];
    l[k] = k === 'producto_id' ? (el.value ? Number(el.value) : null) : el.value;
    if (k === 'producto_id' && l.producto_id) { const p = productos.find(p => p.id == l.producto_id); if (p && unidadNorm(p.unidad)) { l.unidad = unidadNorm(p.unidad); el.closest('.fc-lin').querySelector('[data-k="unidad"]').value = l.unidad; } }
    if ((k === 'cantidad' || k === 'precio') && l.cantidad !== '' && l.precio !== '') {
      const v = Number(String(l.cantidad).replace(',', '.')) * Number(String(l.precio).replace(',', '.'));
      if (!isNaN(v)) { l.importe = String(Math.round(v * 100) / 100).replace('.', ','); el.closest('.fc-lin').querySelector('[data-k="importe"]').value = l.importe; }
    }
    if (k === 'importe' || k === 'cantidad' || k === 'precio') pintarSuma();
  });
  $('#fcLineas').addEventListener('change', e => {
    const el = e.target.closest('[data-k="descripcion"]'); if (!el) return;
    const i = +el.closest('.fc-lin').dataset.i, l = edit.lineas[i];
    if (!l.tipo) l.tipo = adivinarTipo(l.descripcion);
    if (!l.producto_id) { const x = prepararLinea({...l, unidad: l.unidad}); l.producto_id = x.producto_id; l.tipo = l.tipo || x.tipo; }
    pintarLineas();
  });
  $('#fcLineas').addEventListener('click', e => {
    const b = e.target.closest('[data-quitar]'); if (!b) return;
    edit.lineas.splice(+b.dataset.quitar, 1); pintarLineas();
  });
  $('#fcTotal').addEventListener('input', pintarSuma);
  $('#fcAddLinea').onclick = () => {
    edit.lineas.push(prepararLinea({descripcion: ''}));
    pintarLineas();
    const ins = document.querySelectorAll('#fcLineas [data-k="descripcion"]');
    if (ins.length) ins[ins.length - 1].focus();
  };

  async function abrirRevision(f, ayuda) {
    await cargarProductos();
    edit = {...f, lineas: f.lineas.map(prepararLinea)};
    $('#fcRevTit').textContent = f.id ? 'Editar factura' : 'Revisa la factura';
    $('#fcRevAyuda').textContent = ayuda || 'Corrige lo que esté mal. La app recuerda el tipo y el producto para la próxima vez.';
    $('#fcProv').value = f.proveedor || '';
    $('#fcFecha').value = (f.fecha || iso(new Date())).slice(0, 10);
    $('#fcNum').value = f.numero || '';
    $('#fcTotal').value = f.total != null && f.total !== '' ? String(f.total).replace('.', ',') : '';
    $('#fcProvLista').innerHTML = (datos ? datos.proveedores : []).map(p => `<option value="${esc(p)}">`).join('');
    $('#fcErr').textContent = '';
    pintarLineas();
    paso('revisar');
  }

  $('#fcGuardar').onclick = async () => {
    const err = $('#fcErr'); err.textContent = '';
    const lineas = edit.lineas.filter(l => String(l.descripcion).trim());
    if (!$('#fcProv').value.trim()) { err.textContent = 'Escribe el proveedor.'; $('#fcProv').focus(); return; }
    if (!$('#fcFecha').value) { err.textContent = 'Pon la fecha de la factura.'; return; }
    if (!lineas.length) { err.textContent = 'La factura no tiene productos.'; return; }
    const b = $('#fcGuardar'); b.disabled = true; b.textContent = 'Guardando…';
    try {
      const r = await api('factura_guardar', {}, {
        id: edit.id || 0, proveedor: $('#fcProv').value.trim(), numero: $('#fcNum').value.trim(), fecha: $('#fcFecha').value,
        total: $('#fcTotal').value.trim(), texto: edit.texto ?? null,
        lineas: lineas.map(l => ({...l, clave: clave(l.descripcion)})),
      });
      if (!edit.id) { txt.value = ''; guardarBorrador(''); }
      toast('Factura guardada');
      semana = lunes(deIso($('#fcFecha').value));
      edit = null;
      paso('semana'); cargar();
    } catch (e) { err.textContent = e.message; }
    finally { b.disabled = false; b.textContent = '💾 Guardar factura'; }
  };

  /* ---------- Botones ---------- */
  $('#fcAnt').onclick = () => { semana = masDias(semana, -7); cargar(); };
  $('#fcSig').onclick = () => { semana = masDias(semana, 7); cargar(); };
  $('#fcFiltros').onclick = e => { const b = e.target.closest('[data-f]'); if (b && datos) { filtro = b.dataset.f; pintar(); } };
  $('#fcNueva').onclick = () => { paso('pegar'); };
  $('#fcVolver1').onclick = () => paso('semana');
  $('#fcVolver2').onclick = () => paso(edit && edit.id ? 'semana' : 'pegar');
  $('#fcAMano').onclick = () => abrirRevision({proveedor: '', fecha: iso(new Date()), lineas: [{descripcion: ''}]}, 'Escribe los productos de la factura.');
  $('#fcLeer').onclick = async () => {
    const t = txt.value.trim();
    if (!t) { toast('Pega primero el texto de la factura'); txt.focus(); return; }
    const f = leerFactura(t, datos ? datos.proveedores : []);
    f.texto = t;
    const ayuda = f.columnas
      ? 'Google Lens ha copiado la tabla por columnas: he sacado los productos, pero rellena cantidades y precios.'
      : `He encontrado ${f.lineas.length} producto${f.lineas.length === 1 ? '' : 's'}. Revisa que esté bien antes de guardar.`;
    await abrirRevision(f, ayuda);
  };
  $('#fcPegarBtn').onclick = async () => {
    try {
      const t = await navigator.clipboard.readText();
      if (!t.trim()) throw new Error('vacío');
      txt.value = (txt.value.trim() ? txt.value.trimEnd() + '\n' : '') + t.trim();
      guardarBorrador(txt.value); toast('Texto pegado');
    } catch { txt.focus(); toast('Mantén el dedo en el cuadro y pulsa «Pegar»'); }
  };
  $('#fcVaciar').onclick = () => {
    if (txt.value.trim() && !confirm('¿Vaciar el cuadro?')) return;
    txt.value = ''; guardarBorrador(''); txt.focus();
  };
  $('#fcContenido').addEventListener('click', async e => {
    const ed = e.target.closest('[data-editar]'), bo = e.target.closest('[data-borrar]');
    if (ed) {
      const f = datos.facturas.find(x => x.id == ed.dataset.editar);
      if (f) abrirRevision({...f, fecha: f.fecha.slice(0, 10), texto: null});
    } else if (bo) {
      const f = datos.facturas.find(x => x.id == bo.dataset.borrar);
      if (!f || !confirm(`¿Borrar la factura de ${f.proveedor} del ${corta(f.fecha)}? No se puede deshacer. (El stock del almacén no cambia.)`)) return;
      try { await api('factura_eliminar', {}, {id: f.id}); toast('Factura borrada'); cargar(); } catch (err) { toast(err.message); }
    }
  });

  window.abrirFacturas = () => { showView('facturas'); paso('semana'); cargar(); };

  // Lee el texto de la factura nada más tenerlo (botón «Pegar y leer» o compartido desde otra app)
  async function leerYa(t) {
    txt.value = t.trim(); guardarBorrador(txt.value);
    showView('facturas');
    if (!datos) { try { datos = await api('facturas_semana', {desde: iso(semana)}); memoria = new Map(datos.memoria.map(m => [m.clave, m])); } catch {} }
    $('#fcLeer').click();
  }
  $('#fcPegarLeer').onclick = async () => {
    try {
      const t = await navigator.clipboard.readText();
      if (!t.trim()) throw new Error('vacío');
      await leerYa(t);
    } catch { paso('pegar'); txt.focus(); toast('Mantén el dedo en el cuadro, pulsa «Pegar» y luego «Leer factura»'); }
  };

  /* ---------- Texto compartido desde Google Lens u otra app (Compartir → Almacén MT) ---------- */
  const COMPARTIDA = 'seba_factura_compartida';
  try {
    const q = new URLSearchParams(location.search);
    const t = [q.get('title'), q.get('text'), q.get('url')].filter(Boolean).join('\n').trim();
    if (t) {
      localStorage.setItem(COMPARTIDA, t);
      history.replaceState(null, '', location.pathname);   // que no se vuelva a leer al recargar
    }
  } catch {}
  // Espera a que la app haya entrado (servidor encontrado + sesión) y entonces abre la factura compartida
  const vigilar = setInterval(() => {
    let t = null;
    try { t = localStorage.getItem(COMPARTIDA); } catch {}
    if (!t) { clearInterval(vigilar); return; }
    const app = document.getElementById('pantallaApp');
    if (!app || app.hidden) return;
    clearInterval(vigilar);
    try { localStorage.removeItem(COMPARTIDA); } catch {}
    leerYa(t);
  }, 400);
  window._leerFactura = leerFactura;   // para pruebas
})();
